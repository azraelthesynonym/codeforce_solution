#from dust i have come, dust i will be

t=int(input())
while t>0:
	t-=1
	l,r=map(int,input().split())
	
	print(l,l*2)
