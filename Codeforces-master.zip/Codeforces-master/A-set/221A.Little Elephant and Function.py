#from dust i have come, dust i will be

import sys
n=int(input())

sys.stdout.write(str(n)+" ")
for i in range(1,n):
    sys.stdout.write(str(i)+" ")






