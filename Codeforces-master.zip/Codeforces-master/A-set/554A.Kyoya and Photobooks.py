#"from dust i have come, dust i will be"

s=input()
print(26+25*len(s))



