#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
int main()
{
        int i,j,k;
        float p,q,l;

        cin>>l>>p>>q;

        cout<<(p*l)/(p+q);


        return 0;
}
