#from dust i have come dust i will be

k,a,b=map(int,input().split())

print(b//k-(a-1)//k)
