#include<stdio.h>
int main()
{
        long long int n;

        scanf("%I64d",&n);

        printf("25");

        return 0;
}
