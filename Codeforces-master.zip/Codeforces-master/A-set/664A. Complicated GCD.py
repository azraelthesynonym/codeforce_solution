#from dust i have come dust i will be

s,t=input().split()

if s==t:
    print(s)
else:
    print(1)
