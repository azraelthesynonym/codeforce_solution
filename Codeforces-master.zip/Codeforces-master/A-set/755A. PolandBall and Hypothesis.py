#from dust i have come dust i will be
import sys

n=int(input())

if n==1:
    print(3)

elif n==2:
    print(4)

else:
    print(n-2)












