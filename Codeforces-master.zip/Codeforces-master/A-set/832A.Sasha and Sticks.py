#"from dust i have come, dust i will be"

n,k=map(int,input().split())

if((n//k)%2==1):
    print("YES")
else:
    print("NO")

