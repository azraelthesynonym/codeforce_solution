/***from dust i have come, dust i will be***/

#include<bits/stdc++.h>

typedef long long int ll;

#define dbg printf("in\n");
#define nl printf("\n");

using namespace std;

int main()
{
    //freopen("in.txt","r",stdin);

    int i,j,k;
    int n,m;
    int cnt=0;

    scanf("%d",&n);

    int x[n],y[n];



    for(i=0;i<n;i++)
        scanf("%d",&x[i]);

    for(i=0;i<n;i++)
        scanf("%d",&y[i]);


    cout<<"Karen";

    return 0;
}
