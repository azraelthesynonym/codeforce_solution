# from dust i have come, dust i will be

a,b=map(int,input().split())
print(a+b)
