# from dust i have come, dust i will be

a,b=map(int,input().split())

pa=pow(a,b)
pb=pow(b,a)

print(pa-pb)
